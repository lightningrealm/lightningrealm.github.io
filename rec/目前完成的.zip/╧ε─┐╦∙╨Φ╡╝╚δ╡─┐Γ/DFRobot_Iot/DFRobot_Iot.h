#ifndef __DFROBOT_IOT__
#define __DFROBOT_IOT__

#include "Arduino.h"
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

#include<vector>
#include <iostream>
using namespace std;

#define ALIYUN 0
#define ONENET 1
#define MAXTOPICNUMBER 5


typedef void (*MsgHandleCb) (String& message);
typedef void (*HandleCb) (void);
enum Topicnum
{
    topic_0 = 0,
    topic_1,
    topic_2,
    topic_3,
    topic_4
};

class DFRobot_Iot{
  public:
    DFRobot_Iot(void);
    ~DFRobot_Iot(void);
    /*ONENET*/
    void init(String OneNetServer,
              String OneNetProductID, String OneNetDeviceID,
              String OneNetApiKey, const String iotTopics[],
              uint16_t OneNetPort = 6002);
    /*Aliyun*/
    void init(String AliyunServer, String AliProductKey, 
              String AliClientId, String AliDeviceName, 
              String AliDeviceSecret, const String iotTopics[],
              uint16_t AliPort = 1883);
    void setConfig();
    boolean connect();
    boolean connected();
    String getWiFiLocalIP();
    boolean setSoftAP(const char* ssid, const char* pass = NULL);
    String getWiFiSoftIP();
    void disconnect();
    void setMqttCallback(const MsgHandleCb handles[]);
    void setMqttCallback(Topicnum topic_num, const String delimiters, const HandleCb handles);
    void publish(Topicnum topic_num, const String& message);
    void publish(Topicnum topic_num, int64_t i);
    void publish(Topicnum topic_num, uint64_t i){publish(topic_num, (int64_t)i);}
    void publish(Topicnum topic_num, int8_t i){publish(topic_num, (int64_t)i);}
    void publish(Topicnum topic_num, uint8_t i){publish(topic_num, (int64_t)i);}
    void publish(Topicnum topic_num, int16_t i){publish(topic_num, (int64_t)i);}
    void publish(Topicnum topic_num, uint16_t i){publish(topic_num, (int64_t)i);}
    void publish(Topicnum topic_num, int32_t i){publish(topic_num, (int64_t)i);}
    void publish(Topicnum topic_num, uint32_t i){publish(topic_num, (int64_t)i);}
    void publish(Topicnum topic_num, long unsigned int i){publish(topic_num, (int64_t)i);}
    void publish(Topicnum topic_num, double f, int precision = 10);
    void publish(Topicnum topic_num, const char *pCh){publish(topic_num, (const String&)pCh);}
    void publish(Topicnum topic_num, char *pCh){publish(topic_num, (const String&)pCh);}

    void wifiConnect(const char *account, const char *password);
    boolean wifiStatus();
    void wifiDisconnect();

    uint8_t _UseServer = ALIYUN;
    
    /*onenet*/
    String _ApiKey;
    String _ProductID;
    String _DeviceID;
    /*aliyun*/
    String _ProductKey;
    String _ClientId;
    String _DeviceName;
    String _DeviceSecret;
    /*public*/
    String _MQTTSERVER;
    uint16_t _port;
    char * _mqttServer;
    char * _clientId;
    char * _username;
    char * _password;
    MsgHandleCb    mqtt_msgHandleCb[5] = {NULL,NULL,NULL,NULL,NULL};
    vector<HandleCb> mqtt_handleCb[MAXTOPICNUMBER];
    vector<String> mqtt_delimiters[MAXTOPICNUMBER];
    vector<String> mqtt_topicArray;
  private:

};

extern WiFiClient espClient;
extern PubSubClient client;

#endif
