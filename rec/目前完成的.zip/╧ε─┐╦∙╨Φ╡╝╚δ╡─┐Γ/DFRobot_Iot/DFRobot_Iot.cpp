#include "DFRobot_Iot.h"
#include "HMAC_SHA1.h"


#if CONFIG_FREERTOS_UNICORE
#define ARDUINO_RUNNING_CORE_MQTT 0
#else
#define ARDUINO_RUNNING_CORE_MQTT 1
#endif
CHMAC_SHA1 MyHmac_Sha1;
DFRobot_Iot *mqttPt;
volatile static bool firstRegisteredMqttCallback;

String byteToHexStr(unsigned char byte_arr[], int arr_len)  
{  
    String hexstr;  
    for (int i=0;i<arr_len;i++)  
    {  
        char hex1;  
        char hex2;  
        int value=byte_arr[i]; 
        int v1=value/16;  
        int v2=value % 16;  
  
        if (v1>=0&&v1<=9)  
            hex1=(char)(48+v1);  
        else  
            hex1=(char)(55+v1);  

        if (v2>=0&&v2<=9)  
            hex2=(char)(48+v2);  
        else  
            hex2=(char)(55+v2);  

        hexstr=hexstr+hex1+hex2;
    }  
    return hexstr;  
}

static void mqttCallback(char * topic, byte * payload, unsigned int len){
    String _topic = topic;

    for(int i = 0; i < mqttPt->mqtt_topicArray.size(); i++){
        if(_topic == mqttPt->mqtt_topicArray[i]){
            String _payload = (char *)payload;
            _payload = _payload.substring(0,len);

            for(int j = 0; j < mqttPt->mqtt_handleCb[i].size(); j++){
                if(_payload == mqttPt->mqtt_delimiters[i][j]){
                    mqttPt->mqtt_handleCb[i][j]();
                    break;
                }
            }

            if(mqttPt->mqtt_msgHandleCb[i])
                mqttPt->mqtt_msgHandleCb[i](_payload);
            break;
        }
    }
}

static void subscribe(){
    for(int i = 0; i < mqttPt->mqtt_topicArray.size(); i++){
        if(mqttPt->mqtt_topicArray[i] != "$dp"){
            //Serial.println(mqttPt->mqtt_topicArray[i].c_str());
            client.subscribe(mqttPt->mqtt_topicArray[i].c_str());
        }
    }
}

static void mqttTask(void *param){
    while(!client.connected()){
        delay(100);
        yield();
    }
    while(1){
        while(!client.connected()){
            delay(100);
            yield();
        }
        client.loop();
        yield();
    }
}

DFRobot_Iot :: DFRobot_Iot(void){
    mqttPt = this;
    firstRegisteredMqttCallback = true;
}

DFRobot_Iot :: ~DFRobot_Iot(void){
    firstRegisteredMqttCallback = false;
    mqttPt = NULL;
    wifiDisconnect();
}

void DFRobot_Iot::wifiConnect(const char *account, const char *password){
    WiFi.disconnect(true);
    delay(100);
    WiFi.begin(account,password);
}

boolean DFRobot_Iot::wifiStatus(){
    return WiFi.status() == WL_CONNECTED;
}

void DFRobot_Iot::wifiDisconnect(){
    if(client.connected())
        client.disconnect();
    WiFi.disconnect(true);
}

boolean DFRobot_Iot::connect(){
    boolean connectState = false;
    long timeOut = millis();
    while(!wifiStatus()){
        if(millis() - timeOut > 10000 && !wifiStatus())
            return connectState;
        delay(10);
    }
    timeOut = millis();

    client.setServer(this->_mqttServer,this->_port);
    client.setCallback(mqttCallback);
    while(!connectState){
        connectState = client.connect(this->_clientId,this->_username,this->_password);
        if(millis() - timeOut > 5000 && !connectState)
            return connectState;
        delay(10);
    }

    subscribe();
    if(firstRegisteredMqttCallback) {
        xTaskCreatePinnedToCore(mqttTask, "mqttTask", 2048, this, 1, NULL, ARDUINO_RUNNING_CORE_MQTT);
        firstRegisteredMqttCallback = false;
    }
    return connectState;
}

boolean DFRobot_Iot::connected(){
    return client.connected();
}

String DFRobot_Iot::getWiFiLocalIP()
{
    unsigned  int IP_Addr = WiFi.localIP();
    int a1 = IP_Addr>>24;
    IP_Addr = IP_Addr<<8;
    int a2 = IP_Addr>>24;
    IP_Addr = IP_Addr<<8;
    int a3 = IP_Addr>>24;
    IP_Addr = IP_Addr<<8;
    int a4 = IP_Addr>>24;
    char myaddr[50];
    memset(myaddr,'\0',50);
    sprintf(myaddr,"%d.%d.%d.%d",a4,a3,a2,a1);

    String myLocalIP = myaddr;
    return myLocalIP;
}

boolean DFRobot_Iot::setSoftAP(const char* ssid, const char* pass)
{
    return WiFi.softAP(ssid,pass);
}

String DFRobot_Iot::getWiFiSoftIP()
{
    unsigned  int IP_Addr = WiFi.softAPIP();
    int a1 = IP_Addr>>24;
    IP_Addr = IP_Addr<<8;
    int a2 = IP_Addr>>24;
    IP_Addr = IP_Addr<<8;
    int a3 = IP_Addr>>24;
    IP_Addr = IP_Addr<<8;
    int a4 = IP_Addr>>24;
    char myaddr[50];
    memset(myaddr,'\0',50);
    sprintf(myaddr,"%d.%d.%d.%d",a4,a3,a2,a1);
    
    String myLocalIP = myaddr;
    return myLocalIP;
}

void DFRobot_Iot::disconnect(){
    client.disconnect();
}

void DFRobot_Iot::publish(Topicnum topic_num, const String& message)
{
    if(!wifiStatus() || !connected())
        return;

    //Serial.println(this->mqtt_topicArray[topic_num].c_str());
    //Serial.println(message.c_str());
    if(topic_num >= mqtt_topicArray.size()) return;
    client.publish(this->mqtt_topicArray[topic_num].c_str(),message.c_str());
}

void DFRobot_Iot::publish(Topicnum topic_num, double f, int precision)
{
    String str;
    str = String(f,5);
    //Serial.println(str);

    char *p = (char *)(str.c_str() + str.length());
    while(*p == '\0'|| *p == '0'){
        *p = '\0';
        p--;
    }
    if(*p == '.')
        *p = '\0';
    if(str == "-0")
        str = "0";
    long timeOut = millis();
    while(!connected() || !wifiStatus()){
        if(millis() - timeOut > 15000 && (!connected() || !wifiStatus()))
            return;
        delay(10);
    }
    publish(topic_num, (const String&)str);
}

void DFRobot_Iot::publish(Topicnum topic_num, int64_t i)
{
    char buffer[34];
    memset(buffer, 0, 34);
    itoa(i, buffer, 10);
    publish(topic_num, (const String&)buffer);
}


/*Use ONENET cloud platform*/
void DFRobot_Iot :: init(String OneNetServer,
                            String OneNetProductID, String OneNetDeviceID,
                            String OneNetApiKey, const String iotTopics[],
                            uint16_t OneNetPort)
                            {
    this->_MQTTSERVER    = OneNetServer;
    this->_ProductID     = OneNetProductID;
    this->_DeviceID      = OneNetDeviceID;
    this->_ApiKey        = OneNetApiKey;
    this->_port          = OneNetPort;
    this->_UseServer     = ONENET;

    for(int i = 0; i < MAXTOPICNUMBER; i++){
        if(iotTopics[i] != ""){
            this->mqtt_topicArray.push_back(iotTopics[i]);
        }
    }
    setConfig();
}
/*Use Aliyun cloud platform*/
void DFRobot_Iot :: init(String AliyunServer, String AliProductKey, 
                            String AliClientId, String AliDeviceName, 
                            String AliDeviceSecret, const String iotTopics[],
                            uint16_t AliPort)
                            {
    this->_MQTTSERVER    = AliyunServer;
    this->_ProductKey    = AliProductKey;
    this->_ClientId      = AliClientId;
    this->_DeviceName    = AliDeviceName;
    this->_DeviceSecret  = AliDeviceSecret;
    this->_port          = AliPort;
    this->_UseServer     = ALIYUN;

    for(int i = 0; i < MAXTOPICNUMBER; i++){
        if(iotTopics[i] != ""){
            this->mqtt_topicArray.push_back(iotTopics[i]);
        }
    }
    setConfig();
}

void DFRobot_Iot :: setMqttCallback(const MsgHandleCb handles[]){
    for(int i = 0; i < MAXTOPICNUMBER; i++){
        if(handles[i]){
            this->mqtt_msgHandleCb[i] = handles[i];
        }
    }
}

void DFRobot_Iot :: setMqttCallback(Topicnum topic_num, const String delimiters, const HandleCb handles){
    mqtt_handleCb[topic_num].push_back(handles);
    mqtt_delimiters[topic_num].push_back(delimiters);
}

/*alculate the connection username and password, etc.*/
void DFRobot_Iot :: setConfig(){
    if(this->_UseServer == ONENET){
        String tempSERVER = this->_MQTTSERVER;
        uint8_t len = tempSERVER.length();
        if(this->_mqttServer == NULL){
            this->_mqttServer = (char *) malloc(len);
        }
        strcpy(this->_mqttServer,tempSERVER.c_str());
    
        String tempID = this->_DeviceID;
        len = tempID.length();
        if(this->_clientId == NULL){
            this->_clientId = (char *) malloc(len);
        }
        strcpy(this->_clientId,tempID.c_str());

        String tempName = this->_ProductID;
        len = tempName.length();
        this->_username = (char * )malloc(len);
        strcpy(this->_username,tempName.c_str());
    
        String tempPass = this->_ApiKey;
        if(this->_password == NULL){
            this->_password = (char *) malloc(tempPass.length());
        }
        strcpy(this->_password,tempPass.c_str());
    }else if(this->_UseServer == ALIYUN){
        String tempSERVER = (this->_ProductKey + "." + this->_MQTTSERVER);
        uint8_t len = tempSERVER.length();
        uint16_t timestamp = 49;
        if(this->_mqttServer == NULL){
            this->_mqttServer = (char *) malloc(len);
        }
        strcpy(this->_mqttServer,tempSERVER.c_str());
        String tempID = (this->_ClientId + 
                         "|securemode=3"+
                         ",signmethod=" + "hmacsha1"+
                         ",timestamp="+(String)timestamp+"|");
        len = tempID.length();
        if(this->_clientId == NULL){
            this->_clientId = (char *) malloc(len);
        }
        strcpy(this->_clientId,tempID.c_str());
        String Data = ("clientId" + this->_ClientId + 
                         "deviceName" + this->_DeviceName + 
                         "productKey" + this->_ProductKey + 
                         "timestamp" + (String)timestamp);
        byte tempPassWord[20];
        char tempSecret[this->_DeviceSecret.length()];
        char tempData[Data.length()];
        String tempName = (this->_DeviceName + "&" + this->_ProductKey);
        len = tempName.length();
        this->_username = (char * )malloc(len);
        strcpy(this->_username,tempName.c_str());
    
        strcpy(tempData,Data.c_str());
        strcpy(tempSecret,this->_DeviceSecret.c_str());
        MyHmac_Sha1.HMAC_SHA1((byte * )tempData,Data.length(),(byte * )tempSecret,this->_DeviceSecret.length(),tempPassWord);
        String tempPass = byteToHexStr(tempPassWord,sizeof(tempPassWord));
        if(this->_password == NULL){
            this->_password = (char *) malloc(tempPass.length());
        }
        strcpy(this->_password,tempPass.c_str());
    }else{
        
    }

}

WiFiClient espClient;
PubSubClient client(espClient);