(

mount /data
mount -o rw,remount /data
MODDIR=${0%/*}
MODID=`echo "$MODDIR" | sed -n -e 's/\/data\/adb\/modules\///p'`
DIR=$MODDIR/system/priv-app
if [ -d $DIR ]; then
  APP=`ls $DIR`
else
  APP=`ls $MODDIR/system/app`
fi
PKG=com.atmos
     
# cleaning
for PKGS in $PKG; do
  rm -rf /data/user/*/$PKGS
done
for APPS in $APP; do
  rm -f `find /data/dalvik-cache /data/resource-cache -type f -name *$APPS*.apk`
done
rm -rf /metadata/magisk/"$MODID"
rm -rf /mnt/vendor/persist/magisk/"$MODID"
rm -rf /persist/magisk/"$MODID"
rm -rf /data/unencrypted/magisk/"$MODID"
rm -rf /cache/magisk/"$MODID"

) 2>/dev/null


