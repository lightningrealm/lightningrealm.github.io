(

MODDIR=${0%/*}

resetprop ro.audio.monitorRotation true

killall mediaserver
killall audioserver
killall /vendor/bin/hw/android.hardware.audio*service

) 2>/dev/null


