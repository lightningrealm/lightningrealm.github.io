(

mount /data
mount -o rw,remount /data
MODDIR=${0%/*}

# run
sh $MODDIR/sepolicy.sh

# etc
if [ -d /sbin/.magisk ]; then
  MAGISKTMP=/sbin/.magisk
else
  MAGISKTMP=`find /dev -mindepth 2 -maxdepth 2 -type d -name .magisk`
fi
ETC=$MAGISKTMP/mirror/system/etc
VETC=$MAGISKTMP/mirror/vendor/etc
VOETC=$MAGISKTMP/mirror/vendor/odm/etc
MODETC=$MODDIR/system/etc
MODVETC=$MODDIR/system/vendor/etc
MODVOETC=$MODDIR/system/vendor/odm/etc

# conflict
AML=/data/adb/modules/aml
ACDB=/data/adb/modules/acdb
if [ -d $AML ] && [ -d $ACDB ]; then
  rm -rf $ACDB
fi

# directory
SKU=`ls $VETC/audio | grep sku_`
if [ "$SKU" ]; then
  for SKUS in $SKU; do
    mkdir -p $MODVETC/audio/$SKUS
  done
fi
PROP=`getprop ro.build.product`
if [ -d $VETC/audio/"$PROP" ]; then
  mkdir -p $MODVETC/audio/"$PROP"
fi

# audio effects
NAME=*audio*effects*
rm -f `find $MODDIR/system -type f -name $NAME.conf -o -name $NAME.xml`
if [ ! -d $ACDB ] || [ -f $ACDB/disable ]; then
  AE=`find $ETC -maxdepth 1 -type f -name $NAME.conf -o -name $NAME.xml`
  VAE=`find $VETC -maxdepth 1 -type f -name $NAME.conf -o -name $NAME.xml`
  VOAE=`find $VOETC -maxdepth 1 -type f -name $NAME.conf -o -name $NAME.xml`
  cp -f $AE $MODETC
  cp -f $VAE $MODVETC
  cp -f $VOAE $MODVOETC
  if [ "$SKU" ]; then
    for SKUS in $SKU; do
      VSAE=`find $VETC/audio/$SKUS -maxdepth 1 -type f -name $NAME.conf -o -name $NAME.xml`
      cp -f $VSAE $MODVETC/audio/$SKUS
    done
  fi
  if [ -d $VETC/audio/"$PROP" ]; then
    VBAE=`find $VETC/audio/"$PROP" -maxdepth 1 -type f -name $NAME.conf -o -name $NAME.xml`
    cp -f $VBAE $MODVETC/audio/"$PROP"
  fi
fi

# audio policy
NAME=*policy*
rm -f `find $MODDIR/system -type f -name $NAME.conf -o -name $NAME.xml`
AP=`find $ETC -maxdepth 1 -type f -name $NAME.conf -o -name $NAME.xml`
VAP=`find $VETC -maxdepth 1 -type f -name $NAME.conf -o -name $NAME.xml`
VAAP=`find $VETC/audio -maxdepth 1 -type f -name $NAME.conf -o -name $NAME.xml`
VOAP=`find $VOETC -maxdepth 1 -type f -name $NAME.conf -o -name $NAME.xml`
cp -f $AP $MODETC
cp -f $VAP $MODVETC
cp -f $VAAP $MODVETC/audio
cp -f $VOAP $MODVOETC
if [ "$SKU" ]; then
  for SKUS in $SKU; do
    VSAP=`find $VETC/audio/$SKUS -maxdepth 1 -type f -name $NAME.conf -o -name $NAME.xml`
    cp -f $VSAP $MODVETC/audio/$SKUS
  done
fi
if [ -d $VETC/audio/"$PROP" ]; then
  VBAP=`find $VETC/audio/"$PROP" -maxdepth 1 -type f -name $NAME.conf -o -name $NAME.xml`
  cp -f $VBAP $MODVETC/audio/"$PROP"
fi

# run
sh $MODDIR/.aml.sh

# cleaning
FILE=$MODDIR/cleaner.sh
if [ -f $FILE ]; then
  sh $FILE
  rm -f $FILE
fi

) 2>/dev/null


