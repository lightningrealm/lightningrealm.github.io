# type
magiskpolicy --live "type vendor_file"
magiskpolicy --live "type vendor_configs_file"

# sock_file
magiskpolicy --live "dontaudit { system_app priv_app platform_app untrusted_app_29 untrusted_app } property_socket sock_file write"
magiskpolicy --live "allow     { system_app priv_app platform_app untrusted_app_29 untrusted_app } property_socket sock_file write"

# unix_stream_socket
magiskpolicy --live "dontaudit { system_app priv_app platform_app untrusted_app_29 untrusted_app } init unix_stream_socket connectto"
magiskpolicy --live "allow     { system_app priv_app platform_app untrusted_app_29 untrusted_app } init unix_stream_socket connectto"

# property_service
magiskpolicy --live "dontaudit { system_app priv_app platform_app untrusted_app_29 untrusted_app } default_prop property_service set"
magiskpolicy --live "allow     { system_app priv_app platform_app untrusted_app_29 untrusted_app } default_prop property_service set"

# additional
magiskpolicy --live "dontaudit { hal_audio_default audioserver mtk_hal_audio } default_prop file read"
magiskpolicy --live "allow     { hal_audio_default audioserver mtk_hal_audio } default_prop file read"
magiskpolicy --live "dontaudit { hal_audio_default audioserver mtk_hal_audio } diag_device chr_file { read write open ioctl getattr }"
magiskpolicy --live "allow     { hal_audio_default audioserver mtk_hal_audio } diag_device chr_file { read write open ioctl getattr }"


