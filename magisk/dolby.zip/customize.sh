ui_print " "

# info
MODVER=`grep_prop version $MODPATH/module.prop`
MODVERCODE=`grep_prop versionCode $MODPATH/module.prop`
ui_print " ID=$MODID"
ui_print " Version=$MODVER"
ui_print " VersionCode=$MODVERCODE"
ui_print " MagiskVersion=$MAGISK_VER"
ui_print " MagiskVersionCode=$MAGISK_VER_CODE"
ui_print " "

# sdk
NUM=17
if [ "$API" -lt $NUM ]; then
  ui_print "! Unsupported SDK $API. You have to upgrade your"
  ui_print "  Android version at least SDK API $NUM to use this"
  ui_print "  module."
  abort
else
  ui_print "- SDK $API"
  ui_print " "
fi

# .aml.sh
mv -f $MODPATH/aml.sh $MODPATH/.aml.sh

# mod ui
if getprop | grep -Eq "dolby.mod.ui\]: \[1"; then
  APP=Atmos
  FILE=/sdcard/$APP.apk
  DIR=$MODPATH/system/priv-app/$APP
  ui_print "- Using modified UI apk..."
  if [ -f $FILE ]; then
    cp -f $FILE $DIR
    chmod 0644 $DIR/$APP.apk
    ui_print "  Applied"
  else
    ui_print "  ! There is no $FILE file."
    ui_print "    Please place the apk to your internal storage first"
    ui_print "    and reflash!"
  fi
  ui_print " "
fi

# cleaning
ui_print "- Cleaning..."
APP=`ls $MODPATH/system/priv-app`
PKG=com.atmos
for PKGS in $PKG; do
  if [ "$BOOTMODE" == true ]; then
    UNINSTALL=`pm uninstall $PKGS`
  fi
done
for APPS in $APP; do
  rm -f `find /data/dalvik-cache /data/resource-cache -type f -name *$APPS*.apk`
done
rm -f $MODPATH/LICENSE
rm -rf /metadata/magisk/$MODID
rm -rf /mnt/vendor/persist/magisk/$MODID
rm -rf /persist/magisk/$MODID
rm -rf /data/unencrypted/magisk/$MODID
rm -rf /cache/magisk/$MODID
rm -f /data/system/dropbox/*
ui_print " "

# magisk
if [ -d /sbin/.magisk ]; then
  MAGISKTMP=/sbin/.magisk
else
  MAGISKTMP=`find /dev -mindepth 2 -maxdepth 2 -type d -name .magisk`
fi

# function
conflict() {
  for NAMES in $NAME; do
    rm -rf /data/adb/modules_update/$NAMES
    rm -f /data/adb/modules/$NAMES/update
    touch /data/adb/modules/$NAMES/remove
    sh /data/adb/modules/$NAMES/uninstall.sh
    rm -f /data/adb/modules/$NAMES/uninstall.sh
    rm -rf /metadata/magisk/$NAMES
    rm -rf /mnt/vendor/persist/magisk/$NAMES
    rm -rf /persist/magisk/$NAMES
    rm -rf /data/unencrypted/magisk/$NAMES
    rm -rf /cache/magisk/$NAMES
  done
}

# conflict
#NAME="DolbyAudio MotoDolby dsplus"
#conflict

# function
cleanup() {
  sh $DIR/uninstall.sh
  DIR=/data/adb/modules_update/$MODID
  sh $DIR/uninstall.sh
}

# cleanup
DIR=/data/adb/modules/$MODID
FILE=$DIR/module.prop
if getprop | grep -Eq "dolby.cleanup\]: \[1"; then
  ui_print "- Cleaning-up $MODID data..."
  cleanup
  ui_print " "
elif [ -d $DIR ] && ! grep -Eq "$MODNAME" $FILE; then
  ui_print "- Different version detected"
  ui_print "  Cleaning-up $MODID data..."
  cleanup
  ui_print " "
fi

# function
permissive() {
  SELINUX=`getenforce`
  if [ "$SELINUX" == Enforcing ]; then
    setenforce 0
    SELINUX=`getenforce`
    if [ "$SELINUX" == Enforcing ]; then
      abort "! Your device can't be turned to Permissive state."
    fi
    setenforce 1
  fi
  sed -i '1i\
SELINUX=`getenforce`\
if [ "$SELINUX" == Enforcing ]; then\
  setenforce 0\
fi\' $MODPATH/post-fs-data.sh
}

# permissive
if getprop | grep -Eq "dolby.permissive\]: \[1"; then
  ui_print "- Using permissive method"
  rm -f $MODPATH/sepolicy.rule
  permissive
  ui_print " "
elif getprop | grep -Eq "dolby.permissive\]: \[2"; then
  ui_print "- Using both permissive and SE policy patch"
  permissive
  ui_print " "
fi

# function
hide_except_priv_app() {
  for APPS in $APP; do
    mkdir -p $MODPATH/system/app/$APPS
    touch $MODPATH/system/app/$APPS/.replace
    mkdir -p $MODPATH/system/product/app/$APPS
    touch $MODPATH/system/product/app/$APPS/.replace
    mkdir -p $MODPATH/system/product/priv-app/$APPS
    touch $MODPATH/system/product/priv-app/$APPS/.replace
    mkdir -p $MODPATH/system/product/preinstall/$APPS
    touch $MODPATH/system/product/preinstall/$APPS/.replace
    mkdir -p $MODPATH/system/system_ext/app/$APPS
    touch $MODPATH/system/system_ext/app/$APPS/.replace
    mkdir -p $MODPATH/system/system_ext/priv-app/$APPS
    touch $MODPATH/system/system_ext/priv-app/$APPS/.replace
  done
}
fake_oat_priv_app() {
  for APPS in $APP; do
    mkdir -p $MODPATH/system/priv-app/$APPS/oat/$ARCH
    touch $MODPATH/system/priv-app/$APPS/oat/$ARCH/$APPS.odex
    touch $MODPATH/system/priv-app/$APPS/oat/$ARCH/$APPS.vdex
  done
}
hide_app() {
  for APPS in $APP; do
    mkdir -p $MODPATH/system/app/$APPS
    touch $MODPATH/system/app/$APPS/.replace
    mkdir -p $MODPATH/system/priv-app/$APPS
    touch $MODPATH/system/priv-app/$APPS/.replace
    mkdir -p $MODPATH/system/product/app/$APPS
    touch $MODPATH/system/product/app/$APPS/.replace
    mkdir -p $MODPATH/system/product/priv-app/$APPS
    touch $MODPATH/system/product/priv-app/$APPS/.replace
    mkdir -p $MODPATH/system/product/preinstall/$APPS
    touch $MODPATH/system/product/preinstall/$APPS/.replace
    mkdir -p $MODPATH/system/system_ext/app/$APPS
    touch $MODPATH/system/system_ext/app/$APPS/.replace
    mkdir -p $MODPATH/system/system_ext/priv-app/$APPS
    touch $MODPATH/system/system_ext/priv-app/$APPS/.replace
  done
}
hide_app_vendor() {
  for APPS in $APP; do
    mkdir -p $MODPATH/system/vendor/app/$APPS
    touch $MODPATH/system/vendor/app/$APPS/.replace
  done
}
check_app() {
  if [ "$BOOTMODE" == true ]; then
    for APPS in $APP; do
      FILE=`find $MAGISKTMP/mirror/system_root/system\
                 $MAGISKTMP/mirror/system_root/product\
                 $MAGISKTMP/mirror/system_root/system_ext\
                 $MAGISKTMP/mirror/system\
                 $MAGISKTMP/mirror/product\
                 $MAGISKTMP/mirror/system_ext -type f -name $APPS.apk`
      if [ "$FILE" ]; then
        ui_print "- Checking $APPS.apk"
        ui_print "  Please wait..."
        if grep -Eq $UUID $FILE; then
          ui_print "  Your $APPS.apk will be hidden"
          hide_app
        fi
        ui_print " "
      fi
    done
  fi
}
detect_soundfx() {
  if [ "$BOOTMODE" == true ]; then
    if dumpsys media.audio_flinger | grep -Eq $UUID; then
      ui_print "- $NAME is detected"
      ui_print "  It may conflicting with this module"
      ui_print "  Read Github Troubleshootings to disable it"
      ui_print " "
    fi
  fi
}

# hide
fake_oat_priv_app
hide_except_priv_app
#APP="MotoDolbyV3 OPSoundTuner DolbyVisionService Ds Ds1 Ds2 DsUI"
#hide_app
#APP="DolbyVisionService Ds Ds1 Ds2 DsUI"
#hide_app_vendor
if getprop | grep -Eq "disable.dirac\]: \[1" || getprop | grep -Eq "disable.misoundfx\]: \[1"; then
  APP=MiSound
  hide_app
fi

# dirac
FILE=$MODPATH/.aml.sh
APP="XiaomiParts
     ZenfoneParts
     ZenParts
     GalaxyParts"
NAME='dirac soundfx'
UUID=e069d9e0-8329-11df-9168-0002a5d5c51b
if getprop | grep -Eq "disable.dirac\]: \[1"; then
  ui_print "- $NAME will be disabled..."
  sed -i 's/#2//g' $FILE
  ui_print " "
  check_app
else
  detect_soundfx
fi

# misoundfx
NAME=misoundfx
UUID=5b8e36a5-144a-4c38-b1d7-0002a5d5c51b
if getprop | grep -Eq "disable.misoundfx\]: \[1"; then
  ui_print "- $NAME will be disabled..."
  sed -i 's/#3//g' $FILE
  ui_print " "
  check_app
else
  detect_soundfx
fi

# dolby
#APP="DaxUI daxService"
#UUID=9d4921da-8225-4f29-aefa-39537a04bcaa
#check_app

# stream mode
PROP=`getprop stream.mode`
if echo "$PROP" | grep -Eq m; then
  ui_print "- Activating music stream..."
  sed -i 's/#m//g' $FILE
  sed -i 's/musicstream=/musicstream=true/g' $MODPATH/acdb.conf
  ui_print " "
else
  APP="AudioFX MusicFX"
  hide_app
fi
if echo "$PROP" | grep -Eq r; then
  ui_print "- Activating ring stream..."
  sed -i 's/#r//g' $FILE
  ui_print " "
fi
if echo "$PROP" | grep -Eq a; then
  ui_print "- Activating alarm stream..."
  sed -i 's/#a//g' $FILE
  ui_print " "
fi
if echo "$PROP" | grep -Eq v; then
  ui_print "- Activating voice_call stream..."
  sed -i 's/#v//g' $FILE
  ui_print " "
fi
if echo "$PROP" | grep -Eq n; then
  ui_print "- Activating notification stream..."
  sed -i 's/#n//g' $FILE
  ui_print " "
fi

# /priv-app
if [ "$BOOTMODE" == true ]; then
  DIR=$MAGISKTMP/mirror/system/priv-app
else
  DIR=/system/priv-app
fi
if [ ! -d $DIR ]; then
  ui_print "- /system/priv-app is not supported."
  ui_print "  Moving to /system/app..."
  rm -rf $MODPATH/system/app
  mv -f $MODPATH/system/priv-app $MODPATH/system/app
  ui_print " "
fi

# directory
if [ $BOOTMODE == true ]; then
  DIR=$MAGISKTMP/mirror/vendor/lib/soundfx
else
  DIR=/vendor/lib/soundfx
fi
if [ ! -d $DIR ]; then
  ui_print "- /vendor/lib/soundfx is not suported."
  ui_print "  Moving to /system/lib/soundfx..."
  mv -f $MODPATH/system/vendor/lib* $MODPATH/system
  ui_print " "
fi

# permission
ui_print "- Setting permission..."
DIR=`find $MODPATH/system/vendor -type d`
for DIRS in $DIR; do
  chown 0.2000 $DIRS
done
if [ "$API" -gt 25 ]; then
  magiskpolicy --live "dontaudit { vendor_file vendor_configs_file } labeledfs filesystem associate"
  magiskpolicy --live "allow     { vendor_file vendor_configs_file } labeledfs filesystem associate"
  chcon -R u:object_r:vendor_file:s0 $MODPATH/system/vendor
  chcon -R u:object_r:vendor_configs_file:s0 $MODPATH/system/vendor/etc
  chcon -R u:object_r:vendor_configs_file:s0 $MODPATH/system/vendor/odm/etc
fi
ui_print " "






